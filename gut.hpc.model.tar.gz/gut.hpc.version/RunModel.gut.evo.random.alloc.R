#!/usr/bin/env R
# author: Tim Barraclough (t.barraclough@imperial.ac.uk)
# version: 0.2.0 

library(deSolve)

#####################
###FUNCTIONS
#####################

#library(deSolve)

RateMetabolismSaturatingMM <- function(kcat, Km, S, E){
  #multiplying each row of kcat by vector S
  kcat.S <- sweep(kcat,1,S,"*")  
  ##raise to power of the cost of generalism term - added power term May 2014
  numerator <- (E^cost.generalism)*kcat.S         
  #adding vector S to each row of matrix Km
  KmplusS <- sweep(Km,1,S,"+")                    
    
  #element by element division of both arrays
  if (growth.func=="linear") {j<-numerator} else {j<-numerator/KmplusS} 
  
  j[lower.tri(j[,,1])] <- 0
  
  return(j)                  
}

FitnessFunction<-function(i,S,E) {
	
	##michaelis.menten bit
	 if (growth.func=="linear") {
	 	michaelis.menten<-(sweep(kcat[,,i],1,S,"*")) } else {
	
	michaelis.menten<-(sweep(kcat[,,i],1,S,"*")/sweep(Km[,,i],1,S,"+"))
			}
	michaelis.menten<-michaelis.menten*natp[,,i]    ##  ADDED MAY 17th TO CORRECT MISTAKE
	michaelis.menten[!pathway[,,i]]<-0
	
	#tmp<-michaelis.menten
	#tmp[pathway[,,i]]<-michaelis.menten[pathway[,,i]]-(sum(michaelis.menten[pathway[,,i]])-michaelis.menten[pathway[,,i]])/(sum(pathway[,,i])-1)	
	
	tmp<-michaelis.menten
	E.term<-(cost.generalism*E[,,i]^(cost.generalism-1))[pathway[,,i]]
	tmp[pathway[,,i]]<-michaelis.menten[pathway[,,i]]*E.term -(sum(michaelis.menten[pathway[,,i]]*E.term)-E.term*michaelis.menten[pathway[,,i]])/(sum(pathway[,,i])-1)	
		
    return(tmp)

}

GrowthRate <- function(paramsGrowthInt){  

  attach(paramsGrowthInt, warn.conflicts = FALSE)
  w <- rep(0, n)  

  for (sp in seq(1, n)){
    w[sp]=sum(natp[,,sp]*(J[,,sp])) 
   }
   detach(paramsGrowthInt)
   return(w)
}



        
ODE <-function(times, y, parms){
	
  attach(parms, warn.conflicts = FALSE)
   
  S <- y[1:k]  
  dS.dt <- array(0,k) 
  N <-y[(k+1):(k+n)]
  dN.dt <- array(0,n)
  
    #if (times==3000) {S<-S+0.05; print("boo")}

   
   ##changed Feb2014 to make dE.dt 0 by default
  dE.dt <- array(data = 0, dim = c(k,k,n))
  E<-dE.dt
  E[pathway]<-y[(k+n+1):(k+n+sum(pathway))]
  #E <- dE.dt
  J <- RateMetabolismSaturatingMM(kcat, Km, S, E)

  
  
 ##i) growth of bacteria
  paramsGrowthInt <- list(k = k, n = n, natp = natp, J = J, E = E, S = S)
  W <- GrowthRate(paramsGrowthInt)   
  dN.dt <- W*N - dd*N
  
  
 ##ii) substrates
  J.N <-  array(data = 1, dim = c(k,k,n))
  for (species in seq(0, n)){
    J.N[,,species] <- J[,,species]*N[species]
  }

  for (subst in seq(1, k)){
    dS.dt[subst]<- D*(Q[subst] - S[subst]) - sum(J.N[subst,,]) +   
                      sum(J.N[,subst,]) - sum(J.N[,subst,][subst,])                                                
  }  
  
  ##iii) Enzymes - added Feb 2014 to skip these bits if don't want evolution
  if (evolve) {
   
  for (species in seq(1, n)) {
  
        dW.dE <- FitnessFunction(species,S,E)  
          
        #multiplying by the mutation rate
        dE.dt[,,species] <- m[,,species]*dW.dE 
 		
 		##apply boundary condition
        if (min(E[,,species]+dE.dt[,,species])<0) {
        E.tmp<-E[,,species]+dE.dt[,,species]
        E.tmp[E.tmp<0]<-0
        E.tmp<-E.tmp/sum(E.tmp)
        dE.dt[,,species]<-E.tmp-E[,,species]
        }
  }
  }
 
  #no negative concentration of substrates    
  dS.dt[dS.dt + S < 0] <- -S[dS.dt + S < 0]
  #no negative densities of bacteria
  dN.dt[dN.dt + N < 0.000] <- -N[dN.dt + N < 0.000]
   
  detach(parms)
  
  return(list(c(dS.dt,dN.dt,dE.dt[pathway])))  
  #return(list(c(dS.dt,dN.dt)))
}

main <- function(verbose=FALSE){

  #Initial values for the differential equation solver
  y <- c(S = conc.subst, N = density.spec, E = metabolic[pathway])
  #y <- c(S = conc.subst, N = density.spec)
  #E <<- metabolic
  
  
  #parameters to be passed to lsoda
  parms <- list(k = kNumSubst, n = kNumSpec, kcat = kCat, 
            D = kSubstDilutionRate, m = kMutRate, Km = kMichaelis, Q = kInflowConc,
             natp = kAtpPerReaction, dd = kSpecDilutionRate,pathway=pathway)
 
  sol <- lsoda(y,times,ODE,parms,verbose = verbose)
 
  return(list(sol=sol,parms=parms))
}

#parameters="params.R"


###MORE FUNCTIONS FROM FUNCTIONS.R
##METABOLIC ASSIGNMENT FUNCTIONS

##specialists: each substrate used by just one species: if multiple products, allocation from enzyme.allocation of enzyme to each
specialists<-function() {
	metabolic <-  array(data = 0, dim = c(kNumSubst,kNumSubst,kNumSpec))
	for (i in (which(density.spec>0))) {
	metabolic[i,,i]<-enzyme.allocation[i,]}
	return(metabolic) }

##generalists, allocate enzyme to all pathways using continuous broken stick. 	
complementary.generalists<-function() {
	metabolic <-  array(data = 0, dim = c(kNumSubst,kNumSubst,kNumSpec))
	tmp<-which(whole.pathway,arr.ind=T)
	for (i in (1:kNumReac)) {
		metabolic[tmp[i,1],tmp[i,2],]<-broken.stick(kNumSpec)*enzyme.allocation[tmp[i,1],tmp[i,2]]}
	for (i in (1:kNumSpec)) {
		metabolic[,,i]<-metabolic[,,i]/sum(metabolic[,,i])}
	return(metabolic)
}

broken.stick2<-function(n,length) {
		x<-runif(n-1,0,length)
		return(diff(c(0,sort(x),length)))}

##generalists, allocate enzyme to all pathways using continuous broken stick. 
##each species sums to 1, and each enzyme sums to 1 in community	
generalist.broken.stick2D<-function() {

	metabolic <-  array(data = 0, dim = c(kNumSubst,kNumSubst,kNumSpec))
	
	kNumInput<-sum(rowSums(enzyme.allocation)>0)
	
	metabolic.tmp<-matrix(NA,nrow=kNumSpec,ncol=kNumInput)
	##random order of rows and columns
	rows<-sample(1:kNumSpec)
	cols<-sample(1:kNumInput)
	##step 1 - fill in a random row and column
	metabolic.tmp[rows[1],]<-broken.stick2(kNumInput,1)
	metabolic.tmp[-rows[1],cols[1]]<-broken.stick2(kNumSpec-1,1-metabolic.tmp[rows[1],cols[1]])
	
	##step 2 - loop through rest of rows
	for (i in (2:(kNumSpec-1))) {
		metabolic.tmp[rows[i],-cols[1]]<-broken.stick2(kNumSpec-1,1-metabolic.tmp[rows[i],cols[1]])
		while (max(colSums(metabolic.tmp,na.rm=T),na.rm=T)>1) metabolic.tmp[rows[i],-cols[1]]<-broken.stick2(kNumSpec-1,1-metabolic.tmp[rows[i],cols[1]])
		}
		metabolic.tmp[rows[kNumSpec],]<-1-colSums(metabolic.tmp[-rows[kNumSpec],])
				
		##add back terminal substrates
		new.tmp<-matrix(0,nrow=kNumSpec,ncol=kNumSubst)
		new.tmp[,which(rowSums(enzyme.allocation)>0)]<-metabolic.tmp
	
	##loop through and add multiplying by enzyme allocation
	for (i in (1:kNumSpec)) {
		metabolic[,,i]<-new.tmp[i,]*enzyme.allocation}

	return(metabolic)
}

generalist.random.allocation<-function() {
	metabolic <-  array(data = 0, dim = c(kNumSubst,kNumSubst,kNumSpec))
	for (i in (1:kNumSpec)) {
		metabolic[,,i][whole.pathway]<-broken.stick(kNumReac)}
		return(metabolic)}

##generalists, allocate enzyme to all pathways use discrete formulation so all sums work	
complementary.generalists.discrete<-function() {
	if (alloc=="even") {num.subdiv<-prod(unique(1/enzyme.allocation[whole.pathway]))} else {num.subdiv<-10}
	##if its below 10, use lowest multiple above 10
	if (num.subdiv<10) {tmp<-num.subdiv*(2:10);num.subdiv<-min(tmp[tmp>=10])}
	metabolic <-  array(data = 0, dim = c(kNumSubst,kNumSubst,kNumSpec))
	x<-rep(which(whole.pathway,arr.ind=T)[,1],num.subdiv*enzyme.allocation[whole.pathway])
	y<-rep(which(whole.pathway,arr.ind=T)[,2],num.subdiv*enzyme.allocation[whole.pathway])
	z<-sample(rep(1:kNumSpec,num.subdiv))
	for (i in (1:(num.subdiv*kNumSpec))) {
		metabolic[x[i],y[i],z[i]]<-metabolic[x[i],y[i],z[i]]+1/num.subdiv
		}
	return(metabolic)	
}

 
##enzyme allocation: determines whether, in specialist case, splitting pathways have products 1:1 or broken stick splits
allocation<-function(x) {

enzyme.allocation<-whole.pathway

if (x=="even") {
enzyme.allocation[rowSums(whole.pathway)>1,]<-enzyme.allocation[rowSums(whole.pathway)>1,]/rowSums(whole.pathway)[rowSums(whole.pathway)>1]
return(enzyme.allocation) }

if (x=="random") {
for (i in (which(rowSums(whole.pathway)>1))) {
	enzyme.allocation[i,whole.pathway[i,]] <- broken.stick(sum(whole.pathway[i,]))}
	return(enzyme.allocation)}
	
if (x=="random.discrete") {
for (i in (which(rowSums(whole.pathway)>1))) {
	enzyme.allocation[i,whole.pathway[i,]] <- discrete.broken.stick(sum(whole.pathway[i,]))}
	return(enzyme.allocation)}
}


##Calculates predicted substrate concentrations at steady-state with specialists
specialist.predict<-function () {

S<-array(NA,kNumSubst)
N<-array(NA,kNumSpec)

metabolic <- specialists() 

whole.pathway.present<-apply(pathway&metabolic,c(1,2),any)

##positive steady-state solutions for substrates - assign zero if an end-product: use just 1 value from columns with more than 1
tmp<-(kSubstDilutionRate*kMichaelis/(kCat*kAtpPerReaction-kSubstDilutionRate))
S<-rowSums(apply(tmp*metabolic,c(1,2),sum))

##carry substrate concentration through pathway
Y<-kInflowConc

for (i in (1:kNumSubst)) {

	product<-which(whole.pathway.present[i,])
	spec<-which(metabolic[i,product[1],]>0)

	##logical to say whether positive solution is stable or not
	if ((S[i]<=0)|(S[i]>Y[i])) {
		S[i]<-Y[i]
		Y[product]<-Y[product]+0  #i.e. no substrate makes it to next step
		N[spec]<-0} else {
		#if (length(product)==1) {
		#Y[product]<-Y[product]+Y[i]-S[i]   ##i.e. of substrate arriving Y[i], S[i] remains as substrate i, rest moves on to next step
		#N[spec]<-kAtpPerReaction[i,product,spec]*(Y[i]-S[i])
		#						} else {
		Y[product]<-Y[product]+(Y[i]-S[i])*metabolic[i,product,spec]
		N[spec]<-kAtpPerReaction[i,product[1],spec]*(Y[i]-S[i])
		#}  ##i.e. E1 goes to product 1 and E2 goes to product 2 etc.
		} 	
}

##fails to find spec when that species is missing, so reassign
#N[is.na(N)]<-0
tmp<-c(S,N)
names(tmp)<-c(paste("s",1:kNumSubst,sep=""),paste("n",1:kNumSpec,sep=""))
return(tmp)

}


##Works out reaction names in right order
p.names<-function(txt) {
pastey<-function(x) {paste(txt,paste(x,collapse="."),sep="")}
return(apply(which(pathway[,,which(density.spec>0)[1]],arr.ind=T),1,pastey))}

e.names<-function(txt) {
pastey<-function(x) {paste(txt,paste(x,collapse="."),sep="")}
return(apply(which(pathway,arr.ind=T),1,pastey))}

##generate broken stick
broken.stick<-function(n) {
		x<-runif(n-1)
		return(diff(c(0,sort(x),1)))}

discrete.broken.stick<-function(n) {
		x<-sample(1:9,n-1)
		return(diff(c(0,sort(x),10))/10)}


#####################
####RUN FROM HERE
#####################

##use this if running on computer cluster to take index for that particular run
#indx <- as.numeric(Sys.getenv("PBS_ARRAY_INDEX"))
#set.seed(indx) 

##otherwise assign indx here
indx<-1

reps<-indx

growth.func<-"monod"

gen<-NULL
	
##Times for each simulation run
times<-seq(0,20000,0.5)  

##for saving time series - subset of times to save memory
pick.times<-c(0:499,seq(500,999,2),seq(1000,3999,10),seq(4000,40000,1000))/2

##0) Number of species and substrates
kNumSpec<-8		     		
kNumSubst<-11

##1) substrate concentrations in the inflow, initial concentrations and their dilution rate
kInflowConc<-rep(0,kNumSubst)
kInflowConc [1:2]<-c(3,2)
conc.subst <- kInflowConc
kSubstDilutionRate<-0.01

##2) species at start and their dilution rate
density.spec<-rep(0.1,kNumSpec)
kSpecDilutionRate<-kSubstDilutionRate


##3) assign the pathway - simplified based on Kettle et al. 2015 Environmental Microbiology (2015) 17(5), 1615–1630
pathway <-array(FALSE,dim=c(kNumSubst,kNumSubst,kNumSpec))
##starch to malto-oligo
pathway[1,3,]<-TRUE
##inulin to fructo-oligo
pathway[2,4,]<-TRUE
##malto to glucose
pathway[3,5,]<-TRUE
##fructo- to fructose
pathway[4,6,]<-TRUE
##glucose to lactate and acetate
pathway[5,7:8,]<-TRUE
##fructose to lactate and acetate
pathway[6,7:8,]<-TRUE
##lactate to acetate, propionate, butyrate => mainly not acetate but can happen in pig - Duncan et al. 2010 Appl Environ Microbiol - Megasphaera. 2004 Oct; 70(10): 5810–5817.
##according to Morrison & Preston 2016 Gut Microbes. 2016; 7(3): 189–200, goes to all 3 SCFA, but Bourriard et al. cited therein says most goes to butyrate
pathway[7,8:10,]<-TRUE
##acetate to butyrate
pathway[8,10,]<-TRUE
##acetate to methane
pathway[8,11,]<-TRUE
kNumReac<-sum(pathway[,,1])
##set to false if any species are missing
if (min(density.spec)==0) {pathway[,, density.spec ==0]<-FALSE}
whole.pathway<-apply(pathway,c(1,2),any)

##if pathway is branching, assign equal amount of enzyme to each branch point
alloc<-"even"
enzyme.allocation<-allocation(alloc)  


#sort.columns<-function(x) {
#	tmp<-x
#	tmp[which(x[,2]>x[,1]),1:2]<-tmp[which(x[,2]>x[,1]),2:1]
#	return(tmp)}

##assign random parameter values here
cs<-runif(kNumSubst,0.13,1)[which(whole.pathway,arr.ind=T)[,1]]
ms<-runif(kNumSubst,0.13,1)[which(whole.pathway,arr.ind=T)[,1]]
ks<-runif(kNumSubst,0.13,1)[which(whole.pathway,arr.ind=T)[,1]]
ds<-runif(1,0.01,0.05)

names(cs)<-paste("c",1:length(cs),sep="")
names(ms)<-paste("m",1:length(cs),sep="")
names(ks)<-paste("k",1:length(cs),sep="")
names(ds)<-"d"


##The metabolic traits:

##need same value for diverging reactions##

##5) number of ATP molecules generated by each reaction i->j in species k                               	
  kAtpPerReaction <-array(data = 1, dim=c(kNumSubst,kNumSubst,kNumSpec))
 	
##6) Michaelis constant for the enzyme that catalyses reaction i->j in species k  
  kMichaelis <-array(data =1, dim = c(kNumSubst,kNumSubst,kNumSpec))

##7) kCat[i,j,k] = turnover number for the enzyme that catalyses reaction i->j in species k 
  kCat <-array(data =1, dim = c(kNumSubst,kNumSubst,kNumSpec))

	kAtpPerReaction[pathway]<-cs
	kMichaelis[pathway]<-ms
	kCat[pathway]<-ks
	kSubstDilutionRate<-ds
	kSpecDilutionRate<-ds


##a) Run Generalist-Eco code and store in results	

	##Evolve or not? If so, assign positive mutation rate
 	evolve<-FALSE
  	kMutRate<-array(data = 0.0, dim = c(kNumSubst,kNumSubst,kNumSpec))
  	if (evolve) kMutRate[pathway]<-0.05
  	##assign cost of generalism: 1 = linear trade-off; >1 = generalists penalized
  	cost.generalism<-1.0

	##set up generalist enzymes
	metabolic<-generalist.random.allocation()

	##run prog
	results<-main()

	##pull out S, N and E from final results line
	S<-results$sol[length(times),-1][1:kNumSubst]
	N<-results$sol[length(times),-1][(1+ kNumSubst):(kNumSubst+kNumSpec)]
	E<-results$sol[length(times),-1][(kNumSubst+kNumSpec+1):(kNumSubst+kNumSpec +sum(pathway))]

	##make into matrix
	E.eco.gen<-metabolic
	E.eco.gen[pathway]<-E
		##maximum 'specialism' for each enzyme
		E.max<-apply(E.eco.gen,c(1,2),max)[whole.pathway]
		names(E.max)<-paste("Emax.",1:kNumReac,sep="")
		E.conc<-apply(sweep(E.eco.gen,3,N,"*"),c(1,2),sum)[whole.pathway]
		names(E.conc)<-paste("Econc.",1:kNumReac,sep="")

	##any identical phenotypes?
	duplicates<-sum(duplicated(apply(E.eco.gen,3,function(x) {paste(x,collapse="")})))

	time.series.eco<-cbind(results$sol[,-1][,1:kNumSubst],results$sol[,-1][,(1+ kNumSubst):(kNumSubst+kNumSpec)])

	eco <-c(S,N,E.max,E.conc,duplicates=duplicates,
	S.conv=max(S-results$sol[length(times)-1,-1][1:kNumSubst]),
	N.conv=max(N-results$sol[length(times)-1,-1][(1+ kNumSubst):(kNumSubst+kNumSpec)]),
	reps=reps,evolve=evolve,specialist.predict())

##b) Run Generalist-Evo code and store in results	

	##Evolve or not? If so, assign positive mutation rate
	evolve<-TRUE
  	kMutRate<-array(data = 0.0, dim = c(kNumSubst,kNumSubst,kNumSpec))
  	if (evolve) kMutRate[pathway]<-0.05
  	##assign cost of generalism: 1 = linear trade-off; >1 = generalists penalized
  	cost.generalism<-1.0

  	results<-main()

	##pull out S, N and E from final results line
	S<-results$sol[length(times),-1][1:kNumSubst]
	N<-results$sol[length(times),-1][(1+ kNumSubst):(kNumSubst+kNumSpec)]
	E<-results$sol[length(times),-1][(kNumSubst+kNumSpec+1):(kNumSubst+kNumSpec +sum(pathway))]

	##make into matrix
	E.evo.gen<-metabolic
	E.evo.gen[pathway]<-E
	##maximum 'specialism' for each enzyme
	E.max<-apply(E.evo.gen,c(1,2),max)[whole.pathway]
	names(E.max)<-paste("Emax.",1:kNumReac,sep="")
	E.conc<-apply(sweep(E.evo.gen,3,N,"*"),c(1,2),sum)[whole.pathway]
	names(E.conc)<-paste("Econc.",1:kNumReac,sep="")

	##any identical phenotypes?
	duplicates<-sum(duplicated(apply(E.evo.gen,3,function(x) {paste(x,collapse="")})))

	time.series.evo<-cbind(results$sol[,-1][,1:kNumSubst],results$sol[,-1][,(1+ kNumSubst):(kNumSubst+kNumSpec)])

	evo <-c(S,N,E.max,E.conc,duplicates=duplicates,
	S.conv=max(S-results$sol[length(times)-1,-1][1:kNumSubst]),
	N.conv=max(N-results$sol[length(times)-1,-1][(1+ kNumSubst):(kNumSubst+kNumSpec)]),
	E.conv=max(E-results$sol[length(times)-1,-1][(kNumSubst+kNumSpec+1):(kNumSubst+kNumSpec +sum(pathway))]),
	reps=reps,evolve=evolve)

##c) Run Eco-Specialists

	##Evolve or not? If so, assign positive mutation rate
 	evolve<-FALSE
  	kMutRate<-array(data = 0.0, dim = c(kNumSubst,kNumSubst,kNumSpec))
  	if (evolve) kMutRate[pathway]<-0.05
  	##assign cost of generalism: 1 = linear trade-off; >1 = generalists penalized
  	cost.generalism<-1.0

	metabolic<-specialists()

	##run the code and store in results	
	results.spec<-main()

	time.series.eco<-cbind(time.series.eco,results.spec$sol[,-1][,1:kNumSubst],results.spec$sol[,-1][,(1+ kNumSubst):(kNumSubst+kNumSpec)])
	colnames(time.series.eco)<-paste(rep(c("gen.","spec."),each=kNumSubst+kNumSpec),colnames(time.series.eco),sep="")
	time.series.eco<-data.frame(time.series.eco)

	eco<-c(eco,evolve.spec=evolve,
	half.S1.gen=times[which(time.series.eco$gen.S1<mean(range(time.series.eco$gen.S1)))[1]],
	half.S1.spec=times[which(time.series.eco$spec.S1<mean(range(time.series.eco$spec.S1)))[1]],
	half.S2.gen=times[which(time.series.eco$gen.S2<mean(range(time.series.eco$gen.S2)))[1]],
	half.S2.spec=times[which(time.series.eco$spec.S2<mean(range(time.series.eco$spec.S2)))[1]],

	half.S10.gen=times[which(time.series.eco$gen.S10>mean(range(time.series.eco$gen.S10)))[1]],
	half.S10.spec=times[which(time.series.eco$spec.S10>mean(range(time.series.eco$spec.S10)))[1]]
	)

	time.series.eco<-cbind(times=pick.times,time.series.eco[times%in%pick.times,])

##d) Run Evo-Specialists

	##Evolve or not? If so, assign positive mutation rate
 	evolve<-TRUE
  	kMutRate<-array(data = 0.0, dim = c(kNumSubst,kNumSubst,kNumSpec))
  	if (evolve) kMutRate[pathway]<-0.05
  	##assign cost of generalism: 1 = linear trade-off; >1 = generalists penalized
  	cost.generalism<-1.0

	metabolic<-specialists()

	##run the code and store in results	
	results.spec<-main()

	time.series.evo<-cbind(time.series.evo,results.spec$sol[,-1][,1:kNumSubst],results.spec$sol[,-1][,(1+ kNumSubst):(kNumSubst+kNumSpec)])
	colnames(time.series.evo)<-paste(rep(c("gen.","spec."),each=kNumSubst+kNumSpec),colnames(time.series.evo),sep="")
	time.series.evo<-data.frame(time.series.evo)

	##pull out S, N and E from final results line
	S<-results.spec$sol[length(times),-1][1:kNumSubst]
	N<-results.spec$sol[length(times),-1][(1+ kNumSubst):(kNumSubst+kNumSpec)]
	E<-results.spec$sol[length(times),-1][(kNumSubst+kNumSpec+1):(kNumSubst+kNumSpec +sum(pathway))]
	names(S)<-paste("s",1:kNumSubst,sep="")
	names(N)<-paste("n",1:kNumSpec,sep="")

	evo<-c(evo,S,N,evolve.spec=evolve,
	half.S1.gen=times[which(time.series.evo$gen.S1<mean(range(time.series.evo$gen.S1)))[1]],
	half.S1.spec=times[which(time.series.evo$spec.S1<mean(range(time.series.evo$spec.S1)))[1]],
	half.S2.gen=times[which(time.series.evo$gen.S2<mean(range(time.series.evo$gen.S2)))[1]],
	half.S2.spec=times[which(time.series.evo$spec.S2<mean(range(time.series.evo$spec.S2)))[1]],
	half.S10.gen=times[which(time.series.evo$gen.S10>mean(range(time.series.evo$gen.S10)))[1]],
	half.S10.spec=times[which(time.series.evo$spec.S10>mean(range(time.series.evo$spec.S10)))[1]]
	)

	##make into matrix
	E.evo.spec<-metabolic
	E.evo.spec[pathway]<-E

	time.series.evo<-cbind(times=pick.times,time.series.evo[times%in%pick.times,])

##combine and save overall results
results.list<-list(cs=cs,ms=ms,ks=ks,ds=ds,qs=kInflowConc,E.eco.gen=E.eco.gen,E.evo.gen=E.evo.gen,E.evo.spec=E.evo.spec)
save(results.list,file=paste("gut.params.May2017.rep.",reps,".Rdata",sep=""))
write.table(t(matrix(eco,ncol=1,dimnames=list(names(eco)))),paste("gen.gut.eco.May2017.rep.",reps,".txt",sep=""),row.names=F)
write.table(t(matrix(evo,ncol=1,dimnames=list(names(evo)))),paste("gen.gut.evo.May2017.rep.",reps,".txt",sep=""),row.names=F)
save(time.series.eco,file=paste("time.series.gut.eco.May2017.rep.",reps,".Rdata",sep=""))
save(time.series.evo,file=paste("time.series.gut.evo.May2017.rep.",reps,".Rdata",sep=""))


